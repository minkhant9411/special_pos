<template>
    <NavBar />
    <slot />
</template>
<script setup>
import NavBar from "./NavBar.vue";
</script>
<style scoped></style>
