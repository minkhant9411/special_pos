<?php

namespace App\Http\Controllers;

use App\SharedFunctionality;
use Illuminate\Http\Request;

abstract class Controller
{

}
